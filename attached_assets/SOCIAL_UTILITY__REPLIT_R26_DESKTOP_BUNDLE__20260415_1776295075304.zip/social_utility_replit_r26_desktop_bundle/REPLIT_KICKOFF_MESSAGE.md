# Replit Kickoff Message

Send this exact message to Replit when starting the UI execution pass:

```md
Use the provided `R26` handoff packet as the working source of truth. Build only inside the shipped React + Vite dashboard. Use only bundled static data from `public/data/*.json` and bundled downloads from `public/downloads/*`. Keep the six existing page ids and meanings unchanged. Do not add a backend, do not add new data dependencies, and do not redesign the information architecture.

Your work is limited to presentation and UX polish: shell/navigation, hierarchy, readability, state distinction clarity, package/batch/handoff presentation, and required-vs-optional error states.

Before changing code, read:
- `replit.md`
- `handoff/REPLIT_UI_IMPLEMENTATION_BRIEF.md`
- `handoff/REPLIT_UI_QA_CHECKLIST.md`
- `handoff/REPLIT_ISSUE_REPORT_TEMPLATE.md`
- `handoff/MERGEBACK_CLOSEOUT_CHECKLIST.md`

If you find a real blocker, report it using the exact issue template. `presentation_only` stays in Replit and must not request a local mint. Only `contract_gap` or `handoff_packet_gap` may return to local. Deployment is already closed; do not reopen Vercel/GitHub work from this pass. `R27` is reserved for the first meaningful local mergeback closeout after the UI is acceptable.
```
