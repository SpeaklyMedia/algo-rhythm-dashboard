# REPLIT PARALLEL WORK PROTOCOL — R26

## Freeze Point
- `04_OUTPUTS/STRATEGY_DASHBOARD_INDEX.json` remains the frozen dashboard contract for the parallel phase.
- `01_WORKINGSET/strategy_dashboard_replit/public/data/` remains the mirrored static seed bundle.
- `01_WORKINGSET/strategy_dashboard_replit/public/downloads/` remains the only bundled download surface the UI may read from.
- `raw_downloads/SOCIAL_UTILITY__REPLIT_UI_HANDOFF__20260415__R26.zip` is now the authoritative Replit working packet until a real contract or handoff-packet gap is reported.
- Operational freeze point is `R26`; the underlying dashboard contract wire shape remains the embedded `r24-replit-ui-v1` contract unless a separately justified contract mint changes it later.

## Current Priority Order
- First: Replit UI execution inside the frozen packet.
- Second: local support only for `contract_gap` or `handoff_packet_gap`.
- Third: `R27` mergeback closeout after the UI is acceptable.
- Fourth: GitHub Actions Node 20 deprecation maintenance only if operationally necessary.

## Ownership Split
- Replit owns presentation, layout, interaction polish, and static-data rendering inside the provided React + Vite app.
- The local repo owns contract stewardship, packet refresh, acceptance validation, and mergeback packaging.
- The operator console remains out of scope unless the UI later requires a new carried-forward proof surface.

## Stable UI Surface
- Fixed pages: `overview`, `strategy`, `review`, `package`, `batch`, `handoff`
- Stable state distinctions:
  - `promoted_canonical`
  - `latest_successful_run`
  - `review_recommended_run`
  - `latest_package`
  - `latest_batch`
- Required data behavior:
  - missing required datasets block the relevant page
  - missing optional datasets render `Unavailable`

## Allowed Replit Issue Types
### `presentation_only`
- Meaning: the issue is solvable inside the shipped app without changing the bundled data contract or handoff packet.
- Default action: solve in Replit only.
- Local action: none.
- Examples:
  - shell polish
  - typography cleanup
  - clearer status chips
  - table readability
  - card grouping or spacing
  - download button styling

### `contract_gap`
- Meaning: an already-defined page needs data or metadata that the frozen contract does not currently expose cleanly.
- Default action: return the issue to local for an additive contract fix.
- Local action:
  1. update the dashboard index generator and seeded bundle
  2. verify every referenced path and hash
  3. rebuild the handoff packet only if the contract changed
  4. mint the next revision only after the refreshed packet is self-consistent
- Examples:
  - required manifest/path/hash ambiguity
  - required dataset missing for an existing page
  - required vs optional dataset classification is wrong

### `handoff_packet_gap`
- Meaning: the data contract is sufficient, but the packet, docs, or bundled downloads are missing something the UI team needs to work effectively.
- Default action: return the issue to local for an additive packet refresh.
- Local action:
  1. update the relevant handoff docs or bundled download set
  2. rebuild the handoff packet
  3. mint the next revision only after the refreshed packet validates cleanly
- Examples:
  - missing handoff doc
  - missing downloadable artifact needed by the Handoff page
  - missing design-authority or layout metadata in the packet

## Required Replit Issue Report Shape
- `issue_type`
- `affected_page`
- `why_current_packet_is_insufficient`
- `exact_missing_data_doc_or_download`
- `why_this_is_not_presentation_only`

Allowed `affected_page` values:
- `overview`
- `strategy`
- `review`
- `package`
- `batch`
- `handoff`
- `global_shell`

Operational rule:
- Replit must use the issue-report template shipped in the handoff packet.
- `R26` is the reconciled packet closeout mint.
- Any future local revision before mergeback must still be driven by a real `contract_gap` or `handoff_packet_gap`.
- Default expectation is no local support mint at all unless a real gap is reported.
- `R27` remains reserved for the later mergeback closeout unless a real contract or packet gap clearly requires an earlier additive revision.

## Non-Starters For Local Change
- visual preference-only changes Replit can solve in-app
- new backend or API aggregation
- new strategy-generation features
- operator-console and dashboard coupling
- governance-only churn without a UI-driven reason
- deployment reopenings triggered only by successful live rollout status

## Local Response When A Real Gap Exists
1. Confirm the issue is `contract_gap` or `handoff_packet_gap`.
2. Keep the fix additive and scoped to the reported gap.
3. Re-run `python3 01_WORKINGSET/strategy_dashboard_replit/tools/sync_dashboard_data.py` if the contract changed.
4. Rebuild the handoff packet if the packet or contract changed.
5. Run `python3 01_WORKINGSET/algo_evidence_pack/tools/validate.py`.
6. Validate the rebuilt packet by unzipping it into a clean directory and running `npm install` plus `npm run build`.
7. Open a new local revision only after the refreshed packet is self-consistent and only if the packet or contract actually changed.

## Mergeback Closeout
- Trigger: the Replit UI reaches an acceptable design state.
- Local closeout steps:
  1. pull the Replit app changes back into `01_WORKINGSET/strategy_dashboard_replit/`
  2. keep the frozen `R24` data contract unless a separately justified local contract mint already occurred
  3. validate the app locally from the merged static bundle
  4. rebuild the handoff zip from the merged app
  5. confirm no `node_modules`, `dist`, `__pycache__`, or `.pyc` leak into the final artifact
  6. mint one new canonical revision only if the merged app or contract changed materially

## Next Read-Only Audit
- When the Vercel app and GitHub repo arrive, inspect only.
- Use `04_OUTPUTS/VERCEL_GITHUB_AUDIT_INTAKE__20260415__R26.md` as the required intake checklist.
- Do not plan deployment or code migration until that inspection is complete.

## Deferred Maintenance
- Track the GitHub Actions Node 20 deprecation warning as a non-blocking deployment-maintenance item.
- Do not prioritize that work ahead of Replit execution or mergeback unless workflow warnings escalate or deploy runs start failing again.
