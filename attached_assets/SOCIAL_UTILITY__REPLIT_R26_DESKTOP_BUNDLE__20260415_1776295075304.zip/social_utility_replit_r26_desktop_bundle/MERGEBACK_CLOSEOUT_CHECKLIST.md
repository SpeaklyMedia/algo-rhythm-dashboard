# Mergeback Closeout Checklist

Use this only after the Replit UI reaches an acceptable state.

## Preconditions
- The UI still renders from bundled `public/data/*.json` and `public/downloads/*` only.
- No backend or API proxy was added.
- The six page ids are unchanged:
  - `overview`
  - `strategy`
  - `review`
  - `package`
  - `batch`
  - `handoff`
- Any local follow-up issue was already classified as either `contract_gap` or `handoff_packet_gap`.

## Local mergeback steps
1. Pull the Replit app changes back into `01_WORKINGSET/strategy_dashboard_replit/`.
2. Keep the frozen dashboard contract wire shape unless a separately justified local contract mint already occurred before mergeback.
3. Run:
   - `npm install`
   - `npm run build`
4. Rebuild the handoff packet from the merged app.
5. Confirm no `node_modules`, `dist`, `__pycache__`, or `.pyc` files leak into the final artifact.
6. Use `R27` for the first meaningful mergeback closeout only if the merged app materially improves the shipped dashboard or if the contract/packet changed.

## Closeout decision rule
- No contract change and no packet change:
  - rebuild the handoff zip only if needed for delivery
  - do not open a governance-only mint
- Contract or packet changed:
  - rebuild the handoff zip
  - validate locally
  - mint the next canonical revision
