# Replit Execution Loop

## Working rules
- Use the frozen packet as-is.
- Work only inside the shipped React + Vite app.
- Use only bundled `public/data/*.json` and `public/downloads/*`.
- Keep page ids unchanged:
  - `overview`
  - `strategy`
  - `review`
  - `package`
  - `batch`
  - `handoff`
- Do not add a backend, API proxy, or new data dependency.
- Do not change route meanings or redesign the information architecture.

## Allowed work in Replit
- shell polish
- navigation clarity
- page readability
- package/batch/handoff presentation
- state distinction clarity
- required-vs-optional error-state treatment

## Required reporting loop
Replit should report back in only one of these forms.

### Progress update
```md
type: progress_update
what_changed: <short paragraph or bullet list>
pages_improved: <one or more page ids>
what_remains: <short paragraph or bullet list>
current_build_status: <pass|fail plus short note>
```

### Issue report
Use `REPLIT_ISSUE_REPORT_TEMPLATE.md` exactly.

Allowed `issue_type` values:
- `presentation_only`
- `contract_gap`
- `handoff_packet_gap`

## Local handling rule
- `presentation_only`
  - no local action
  - Replit continues
- `contract_gap`
  - local additive contract fix
  - packet rebuild only if the contract changed
  - open a local support revision only if packet contents or the contract actually changed
- `handoff_packet_gap`
  - local additive packet/doc/download fix
  - packet rebuild only if packet contents changed
  - open a local support revision only if packet contents actually changed

## Priority order
- First: finish Replit UI work inside the frozen `R26` packet.
- Second: return only real `contract_gap` or `handoff_packet_gap` issues to local.
- Third: request mergeback only after the UI is acceptable and no unresolved gap remains.
- Fourth: treat GitHub Actions Node 20 deprecation as deferred maintenance, not as a UI blocker.

## Completion criteria
Replit is done when:
- `npm install` passes
- `npm run dev -- --host 0.0.0.0 --port 3000` runs
- `npm run build` passes
- all six pages render from bundled static data only
- required blocking errors are visually distinct from optional `Unavailable` states
- promoted/latest/reviewed/package/batch states are clearly differentiated
- the shell feels coherent with the documented hybrid direction
- no unresolved `contract_gap` or `handoff_packet_gap` remains

## Mergeback trigger
- Once the UI is acceptable, switch to `MERGEBACK_CLOSEOUT_CHECKLIST.md`.
- Do not request mergeback while unresolved contract or packet gaps remain.
