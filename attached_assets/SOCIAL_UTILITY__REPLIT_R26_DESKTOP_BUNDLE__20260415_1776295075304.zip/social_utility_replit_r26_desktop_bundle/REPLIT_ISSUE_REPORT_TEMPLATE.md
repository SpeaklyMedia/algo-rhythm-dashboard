# Replit Issue Report Template

Use this exact shape when sending anything back to the local repo.

## Required fields
- `issue_type`
- `affected_page`
- `why_current_packet_is_insufficient`
- `exact_missing_data_doc_or_download`
- `why_this_is_not_presentation_only`

## Allowed `issue_type` values
- `presentation_only`
- `contract_gap`
- `handoff_packet_gap`

## Decision rule
- `presentation_only`
  - solve in Replit only
  - do not request a local mint
- `contract_gap`
  - use only when an already-defined page cannot be completed from the frozen bundled contract
- `handoff_packet_gap`
  - use only when the contract is sufficient but the packet, docs, or bundled downloads are insufficient

## Current operating note
- The active phase is Replit UI execution against the frozen `R26` packet.
- Local repo stays dormant unless this template identifies a real `contract_gap` or `handoff_packet_gap`.
- `R27` is reserved for the first meaningful mergeback closeout, not for routine support or deployment follow-up.

## Required `affected_page` values
- `overview`
- `strategy`
- `review`
- `package`
- `batch`
- `handoff`
- `global_shell`

## Report format
```md
issue_type: <presentation_only|contract_gap|handoff_packet_gap>
affected_page: <overview|strategy|review|package|batch|handoff|global_shell>
why_current_packet_is_insufficient: <one short paragraph>
exact_missing_data_doc_or_download: <exact file, field, manifest, or packet gap>
why_this_is_not_presentation_only: <one short paragraph>
```

## Examples
### Presentation-only
```md
issue_type: presentation_only
affected_page: review
why_current_packet_is_insufficient: The current packet is sufficient. The problem is only that the ranking table is visually dense and hard to scan.
exact_missing_data_doc_or_download: none
why_this_is_not_presentation_only: not applicable
```

### Contract gap
```md
issue_type: contract_gap
affected_page: handoff
why_current_packet_is_insufficient: The page needs a stable hash for the promoted package manifest, but the frozen dashboard bundle does not expose it directly.
exact_missing_data_doc_or_download: missing hash field for latest package manifest in dashboard_index.json or bundled manifest metadata
why_this_is_not_presentation_only: The information is not present in the bundled data, so it cannot be solved by layout or styling alone.
```

### Handoff packet gap
```md
issue_type: handoff_packet_gap
affected_page: handoff
why_current_packet_is_insufficient: The UI needs to expose a bundled local download, but the packet does not currently include that file in public/downloads.
exact_missing_data_doc_or_download: missing bundled download artifact in public/downloads
why_this_is_not_presentation_only: The needed file is absent from the packet, so the UI cannot link to it locally.
```
