# BATCH_SUMMARY

Batch id: `20260416T134500Z`
Review id: `20260416T134500Z`
Batch zip: `STRATEGY_RUN_BATCH__20260416T134500Z__20260416T134500Z.zip`

## Included Runs

- `20260414T232200Z`: mode `promoted_canonical`, selected cards `8`, package zip `04_OUTPUTS/STRATEGY_BATCHES/20260416T134500Z/STRATEGY_RUN_PACKAGE__20260414T232200Z__20260416T134500Z.zip`
- `20260414T232000Z`: mode `reviewed_promotable`, selected cards `8`, package zip `04_OUTPUTS/STRATEGY_BATCHES/20260416T134500Z/STRATEGY_RUN_PACKAGE__20260414T232000Z__20260416T134500Z.zip`
- `20260414T232500Z`: mode `reviewed_promotable`, selected cards `8`, package zip `04_OUTPUTS/STRATEGY_BATCHES/20260416T134500Z/STRATEGY_RUN_PACKAGE__20260414T232500Z__20260416T134500Z.zip`
- `20260416T124500Z`: mode `reviewed_promotable`, selected cards `8`, package zip `04_OUTPUTS/STRATEGY_BATCHES/20260416T134500Z/STRATEGY_RUN_PACKAGE__20260416T124500Z__20260416T134500Z.zip`

## Notes

- Batch assembly is deterministic and review-bound to the promotable cohort from the supplied recommendation.
- The promoted canonical run keeps `package_mode = promoted_canonical`; other promotable runs are packaged as `reviewed_promotable`.
- Top-level Lane B compatibility files remain unchanged by batch assembly.

