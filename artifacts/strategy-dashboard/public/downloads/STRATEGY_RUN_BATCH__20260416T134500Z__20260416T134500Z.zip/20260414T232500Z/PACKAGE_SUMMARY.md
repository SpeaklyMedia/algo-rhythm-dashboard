# PACKAGE_SUMMARY

Package id: `20260416T134500Z`
Run id: `20260414T232500Z`
Review id: `20260416T134500Z`
Package mode: `reviewed_promotable`
Zip filename: `STRATEGY_RUN_PACKAGE__20260414T232500Z__20260416T134500Z.zip`

## Contents

- `CONTENT_OBJECT.json`
- `TREND_SHORTLIST.json`
- `PLATFORM_SIGNAL_SELECTION.json`
- `VIABILITY_SCORECARD.json`
- `FOUR_TIER_ADAPTATIONS.json`
- `EXPERIMENT_PLAN.json`
- `CAMPAIGN_LEDGER.seed.json`
- `STRATEGY_ARTIFACT_SET_SUMMARY.md`
- `RUN_MANIFEST.json`
- `sample_content_brief.json`
- `content_brief.schema.json`
- `PROMOTION_RECOMMENDATION.json`
- `RUN_REVIEW_INDEX.json`
- `RUN_COMPARISON_SCORECARD.json`
- `RUN_REVIEW_SUMMARY.md`
- `STRATEGY_RUN_REVIEW_REPORT__20260416T134500Z__R34.json`
- `SELECTED_SIGNAL_CARDS.json`
- `PACKAGE_SUMMARY.md`

## Selected Cards

- `LinkedIn`: LI_SHIFT_DWELL, LI_PIPELINE
- `TikTok`: TT_FACTORS, TT_SHIFT_CONTROLS
- `Meta`: META_UNCONNECTED_SHARE, IG_EXPLORE_FUNNEL
- `X`: X_PIPELINE, X_RANKER

## Notes

- Package mode is `reviewed_promotable` and the package is review-bound to `20260416T134500Z`.
- Package assembly is deterministic and reuses the reviewed run without regenerating strategy outputs.
- `PACKAGE_MANIFEST.json` remains outside the package zip so it can lock the final zip sha256 without recursive drift.

