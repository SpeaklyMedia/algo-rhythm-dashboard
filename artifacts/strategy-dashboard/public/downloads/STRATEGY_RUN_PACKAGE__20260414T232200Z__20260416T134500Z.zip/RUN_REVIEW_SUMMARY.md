# RUN_REVIEW_SUMMARY

Review id: `20260416T134500Z`
Recommended run: `20260414T232200Z`

## Ranked Runs

### Rank 1 — 20260414T232200Z
- Total score: `100`
- Platform coverage: `4/4`
- Selected cards: `8`
- Promoted before review: `False`

### Rank 2 — 20260414T232000Z
- Total score: `100`
- Platform coverage: `4/4`
- Selected cards: `8`
- Promoted before review: `False`

### Rank 3 — 20260414T232500Z
- Total score: `100`
- Platform coverage: `4/4`
- Selected cards: `8`
- Promoted before review: `False`

### Rank 4 — 20260416T124500Z
- Total score: `100`
- Platform coverage: `4/4`
- Selected cards: `8`
- Promoted before review: `True`

## Excluded Runs

- `20260414T231500Z`: output_path_mismatch:CONTENT_OBJECT.json, output_path_mismatch:TREND_SHORTLIST.json, output_path_mismatch:PLATFORM_SIGNAL_SELECTION.json, output_path_mismatch:VIABILITY_SCORECARD.json, output_path_mismatch:FOUR_TIER_ADAPTATIONS.json, output_path_mismatch:EXPERIMENT_PLAN.json, output_path_mismatch:CAMPAIGN_LEDGER.seed.json, output_path_mismatch:STRATEGY_ARTIFACT_SET_SUMMARY.md
- `20260414T231700Z`: output_path_mismatch:CONTENT_OBJECT.json, output_path_mismatch:TREND_SHORTLIST.json, output_path_mismatch:PLATFORM_SIGNAL_SELECTION.json, output_path_mismatch:VIABILITY_SCORECARD.json, output_path_mismatch:FOUR_TIER_ADAPTATIONS.json, output_path_mismatch:EXPERIMENT_PLAN.json, output_path_mismatch:CAMPAIGN_LEDGER.seed.json, output_path_mismatch:STRATEGY_ARTIFACT_SET_SUMMARY.md
